package numberguessinggame;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        Random r = new Random();
        int difficulty;

        System.out.println("""
                           Welcome to the Number Guessing Game!
                           I'm thinking of a number between 1 and 100.
                           You have 5 chances to guess the correct number.""");

        System.out.println();

        System.out.println("""
                           Please select the difficulty level:
                           1. Easy (10 chances)
                           2. Medium (5 chances)
                           3. Hard (3 chances)""");

        while (true) {
            try {
                System.out.print("Enter your choice: ");
                difficulty = s.nextInt();

                switch (difficulty) {
                    case 1 ->
                        System.out.println("Great! You have selected the Easy difficulty level.");
                    case 2 ->
                        System.out.println("Great! You have selected the Medium difficulty level.");
                    case 3 ->
                        System.out.println("Great! You have selected the Hard difficulty level.");
                    default -> {
                        System.out.println("Incorrect entry, only three levels exist!(1, 2 or 3)");
                        continue;
                    }
                }
                break;

            } catch (InputMismatchException e) {
                System.out.println("The entry is incorrect, only numbers!(1, 2, or 3)");
                s.nextLine();
            }
        }
        int maxTries;
        switch (difficulty) {
            case 1:
                maxTries = 10;
                break;
            case 2:
                maxTries = 5;
                break;
            case 3:
                maxTries = 3;
                break;
            default:
                maxTries = 5;
                break;
        }


        int targetNumber = r.nextInt(100) + 1;
        boolean guessedCorrectly = false;

        System.out.println("\nI have selected a number between 1 and 100. Try to guess it!");

        
        for (int i = 1; i <= maxTries; i++) {
            System.out.print("Guess #" + i + ": ");
            int guess;

            try {
                guess = s.nextInt();

                if (guess == targetNumber) {
                    System.out.println("Congratulations! You guessed the correct number!");
                    guessedCorrectly = true;
                    break;
                } else if (guess < targetNumber) {
                    System.out.println("Too low! Try a higher number.");
                } else {
                    System.out.println("Too high! Try a lower number.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number between 1 and 100.");
                s.nextLine();
                i--;
            }
        }

       
        if (!guessedCorrectly) {
            System.out.println("Sorry, you've used all your tries. The correct number was " + targetNumber + ".");
        }

        System.out.println("Thanks for playing!");

    }

}
